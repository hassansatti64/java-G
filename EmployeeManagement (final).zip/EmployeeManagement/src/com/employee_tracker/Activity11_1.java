//Importing classes
import java.io.*;
import java.util.*;

public class Activity11_1 {
    public static void main(String[] args) {

                //Specifying the file path
                String filePath = "students.txt";

                //Reading the contents of the file
                List<String> lines = new ArrayList<>();
                try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        lines.add(line);
                    }
                } catch (IOException e) {
                    System.out.println("An error occurred while reading the file.");
                    e.printStackTrace();
                    return;
                }

                //Finding the maximum marks
                int maxMarks = 0;
                for (String line : lines) {
                    String[] studentData = line.split(", ");
                    int marks = Integer.parseInt(studentData[2].trim());

                    if (marks > maxMarks) {
                        maxMarks = marks;
                    }
                }

                //Finding the name of the student with maximum marks
                List<String> studentsWithMaxMarks = new ArrayList<>();
                for (String line : lines) {
                    String[] studentData = line.split(", ");
                    String name = studentData[1].trim();
                    int marks = Integer.parseInt(studentData[2].trim());

                    if (marks == maxMarks) {
                        studentsWithMaxMarks.add(name);
                    }
                }

                //Printing the name of the student with maximum marks
                System.out.println("Student with the maximum marks:");
                for (String name : studentsWithMaxMarks) {
                    System.out.println(name);
                }
            }
        }












